// Import the WelcomeBanner component
import { WelcomeBanner } from "@/components/layout/welcome-banner"
import Link from "next/link"

// Replace the existing content with the WelcomeBanner
export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-between p-4 md:p-8 lg:p-12">
      <div className="w-full max-w-6xl mx-auto space-y-8">
        <WelcomeBanner />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-xl font-semibold mb-4 text-[#003366]">For Schools</h2>
            <p className="mb-4 text-gray-700">
              Register your school to access our comprehensive school management system.
            </p>
            <div className="flex justify-end">
              <Link
                href="/admin-select"
                className="bg-[#003366] text-white px-4 py-2 rounded hover:bg-[#002244] transition-colors"
              >
                School Login
              </Link>
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-xl font-semibold mb-4 text-[#003366]">For Parents</h2>
            <p className="mb-4 text-gray-700">
              Access your child's academic information and stay connected with their progress.
            </p>
            <div className="flex justify-end">
              <Link
                href="/parent-login"
                className="bg-[#009975] text-white px-4 py-2 rounded hover:bg-[#007755] transition-colors"
              >
                Parent Login
              </Link>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-xl font-semibold mb-4 text-[#003366]">System Administration</h2>
          <p className="mb-4 text-gray-700">
            Access system administration features to manage schools, users, and system settings.
          </p>
          <div className="flex justify-end">
            <Link
              href="/system-admin/login"
              className="bg-[#F0B323] text-white px-4 py-2 rounded hover:bg-[#D9A31D] transition-colors"
            >
              System Admin Login
            </Link>
          </div>
        </div>
      </div>
    </main>
  )
}
