import { SystemAdminLogin } from "@/components/auth/system-admin-login"
import { AppLogo } from "@/components/layout/app-logo"

export default function SystemAdminLoginPage() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-50 px-4">
      <div className="w-full max-w-md mb-6">
        <AppLogo position="center" size="large" showText={true} />
      </div>
      <SystemAdminLogin />
      <p className="mt-8 text-center text-sm text-gray-500">
        This login is restricted to system administrators only.
        <br />
        For other roles, please use the{" "}
        <a href="/admin-select" className="font-medium text-blue-600 hover:text-blue-500">
          main login page
        </a>
        .
      </p>
    </div>
  )
}
