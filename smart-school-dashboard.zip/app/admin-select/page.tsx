import Link from "next/link"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { getAllRoles } from "@/lib/roles-config"
import { ShieldAlert } from "lucide-react"

export default function AdminSelectPage() {
  const roles = getAllRoles()

  return (
    <div className="container mx-auto py-10">
      <Card className="w-full max-w-3xl mx-auto">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl">Select Administrator Role</CardTitle>
          <CardDescription>Choose your role to log in or sign up for the ShuleVerse system</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mb-6">
            <Card className="border-red-200 bg-red-50">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center">
                  <ShieldAlert className="h-5 w-5 mr-2 text-red-600" />
                  System Administrator
                </CardTitle>
                <CardDescription className="text-red-700">
                  Manage all schools and users in the ShuleVerse platform
                </CardDescription>
              </CardHeader>
              <CardFooter className="pt-2">
                <Button asChild variant="destructive" className="w-full">
                  <Link href="/system-admin/login">System Admin Login</Link>
                </Button>
              </CardFooter>
            </Card>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {roles.map((role) => (
              <Card key={role.id} className="border hover:border-blue-500 transition-colors">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">{role.name}</CardTitle>
                </CardHeader>
                <CardContent className="pb-2">
                  <p className="text-sm text-gray-500">{role.description}</p>
                </CardContent>
                <CardFooter className="flex justify-between pt-0">
                  <Button asChild variant="outline" size="sm">
                    <Link href={`/login/${role.id}`}>Login</Link>
                  </Button>
                  <Button asChild size="sm">
                    <Link href={`/signup/${role.id}`}>Sign Up</Link>
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </CardContent>
        <CardFooter className="flex justify-center">
          <Button asChild variant="ghost">
            <Link href="/">Back to Home</Link>
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}
