import type React from "react"
import { DashboardNavigation } from "@/components/dashboard/dashboard-navigation"

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className="flex min-h-screen">
      <aside className="hidden md:flex w-64 flex-col border-r bg-background p-6">
        <div className="flex h-14 items-center px-4 font-semibold">
          <span className="text-lg">ShuleVerse</span>
        </div>
        <div className="flex-1 overflow-auto py-2">
          <DashboardNavigation />
        </div>
      </aside>
      <div className="flex-1">{children}</div>
    </div>
  )
}
