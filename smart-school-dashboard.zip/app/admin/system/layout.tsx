"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { AppHeader } from "@/components/layout/app-header"

export default function SystemAdminLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter()
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Check if the user is logged in as system admin
    const checkAuth = () => {
      const userRole = localStorage.getItem("userRole")
      const isAuth = localStorage.getItem("isAuthenticated") === "true"

      if (!isAuth || userRole !== "system-admin") {
        router.push("/system-admin/login")
        return
      }

      setIsAuthenticated(true)
      setLoading(false)
    }

    checkAuth()
  }, [router])

  if (loading) {
    return <div className="flex items-center justify-center min-h-screen">Loading...</div>
  }

  if (!isAuthenticated) {
    return null // Will redirect in useEffect
  }

  return (
    <div className="flex flex-col min-h-screen">
      <AppHeader isHomePage={false} />
      <main className="flex-1 bg-gray-50">{children}</main>
    </div>
  )
}
