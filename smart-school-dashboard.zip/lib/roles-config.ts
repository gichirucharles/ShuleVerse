export type AdminRole =
  | "system-admin"
  | "head-teacher"
  | "deputy-head"
  | "class-teacher"
  | "teacher"
  | "director"
  | "accountant"
  | "nurse"
  | "counselor"

export interface RoleConfig {
  id: AdminRole
  name: string
  description: string
  dashboardPath: string
  requiresApproval: boolean
  approvedBy: AdminRole[]
  canApprove: AdminRole[]
  permissions: string[]
}

export const ADMIN_ROLES: Record<AdminRole, RoleConfig> = {
  "system-admin": {
    id: "system-admin",
    name: "System Administrator",
    description: "Manages the entire system and all user accounts",
    dashboardPath: "/admin/system",
    requiresApproval: false,
    approvedBy: [],
    canApprove: [
      "head-teacher",
      "deputy-head",
      "class-teacher",
      "teacher",
      "director",
      "accountant",
      "nurse",
      "counselor",
    ],
    permissions: ["manage_all_users", "system_configuration", "view_all_data", "approve_users"],
  },
  "head-teacher": {
    id: "head-teacher",
    name: "Head Teacher",
    description: "Oversees all school operations and staff",
    dashboardPath: "/admin/head-teacher",
    requiresApproval: true,
    approvedBy: ["system-admin"],
    canApprove: ["deputy-head", "class-teacher", "teacher", "accountant", "nurse", "counselor"],
    permissions: ["manage_teachers", "manage_students", "view_all_reports", "approve_reports", "manage_curriculum"],
  },
  "deputy-head": {
    id: "deputy-head",
    name: "Deputy Head Teacher",
    description: "Assists the head teacher in school management",
    dashboardPath: "/admin/deputy-head",
    requiresApproval: true,
    approvedBy: ["system-admin", "head-teacher"],
    canApprove: ["class-teacher", "teacher"],
    permissions: ["manage_teachers", "manage_students", "view_reports", "approve_class_reports"],
  },
  "class-teacher": {
    id: "class-teacher",
    name: "Class Teacher",
    description: "Manages a specific class and its students",
    dashboardPath: "/admin/class-teacher",
    requiresApproval: true,
    approvedBy: ["system-admin", "head-teacher", "deputy-head"],
    canApprove: [],
    permissions: ["manage_class_students", "input_grades", "create_reports", "communicate_with_parents"],
  },
  teacher: {
    id: "teacher",
    name: "Teacher",
    description: "Teaches specific subjects",
    dashboardPath: "/admin/teacher",
    requiresApproval: true,
    approvedBy: ["system-admin", "head-teacher", "deputy-head"],
    canApprove: [],
    permissions: ["input_grades", "view_assigned_classes", "communicate_with_parents"],
  },
  director: {
    id: "director",
    name: "School Director",
    description: "Oversees school governance and strategic direction",
    dashboardPath: "/admin/director",
    requiresApproval: true,
    approvedBy: ["system-admin"],
    canApprove: ["head-teacher"],
    permissions: ["view_all_reports", "view_financial_reports", "strategic_planning"],
  },
  accountant: {
    id: "accountant",
    name: "Accountant",
    description: "Manages school finances and fee collection",
    dashboardPath: "/admin/accountant",
    requiresApproval: true,
    approvedBy: ["system-admin", "head-teacher"],
    canApprove: [],
    permissions: ["manage_finances", "track_fees", "generate_financial_reports"],
  },
  nurse: {
    id: "nurse",
    name: "School Nurse",
    description: "Provides healthcare services to students",
    dashboardPath: "/admin/nurse",
    requiresApproval: true,
    approvedBy: ["system-admin", "head-teacher"],
    canApprove: [],
    permissions: ["manage_health_records", "administer_medication", "communicate_with_parents"],
  },
  counselor: {
    id: "counselor",
    name: "School Counselor",
    description: "Provides guidance and counseling to students",
    dashboardPath: "/admin/counselor",
    requiresApproval: true,
    approvedBy: ["system-admin", "head-teacher"],
    canApprove: [],
    permissions: ["manage_counseling_records", "schedule_sessions", "communicate_with_parents"],
  },
}

export const getRoleConfig = (role: AdminRole): RoleConfig => {
  return ADMIN_ROLES[role]
}

export const getAllRoles = (): RoleConfig[] => {
  return Object.values(ADMIN_ROLES)
}

export const canRoleApprove = (approverRole: AdminRole, roleToApprove: AdminRole): boolean => {
  return ADMIN_ROLES[approverRole].canApprove.includes(roleToApprove)
}

export const needsApprovalFrom = (role: AdminRole): AdminRole[] => {
  return ADMIN_ROLES[role].approvedBy
}
