// Mock authentication service for demonstration purposes
// In a real application, this would connect to a backend API

import { v4 as uuidv4 } from "uuid"

// Define user roles
export type UserRole =
  | "student"
  | "parent"
  | "teacher"
  | "head-teacher"
  | "deputy-head-teacher"
  | "director"
  | "school-admin"
  | "system-admin"
  | "school-nurse"
  | "school-counselor"

// Define user interface
export interface User {
  id: string
  name?: string
  email: string
  role: UserRole
  schoolId?: string
  schoolName?: string
  classId?: string
  className?: string
}

// Define login credentials interface
export interface LoginCredentials {
  email: string
  password: string
  role: UserRole
  schoolId?: string
}

// Define login response interface
export interface LoginResponse {
  success: boolean
  message: string
  user?: User
}

// Define signup credentials interface
export interface SignupCredentials {
  name: string
  email: string
  password: string
  confirmPassword: string
  role: UserRole
  schoolId?: string
  schoolName?: string
  classId?: string
  className?: string
}

// Define signup response interface
export interface SignupResponse {
  success: boolean
  message: string
  user?: User
}

// Mock user data
const mockUsers: User[] = [
  {
    id: "1",
    name: "John Doe",
    email: "admin@shuleverse.com",
    role: "system-admin",
  },
  {
    id: "2",
    name: "Charles Muiruri",
    email: "charlesmuiruri024@gmail.com",
    role: "system-admin",
  },
  {
    id: "3",
    name: "Jane Smith",
    email: "director@example.com",
    role: "director",
    schoolId: "1",
    schoolName: "Example School",
  },
  {
    id: "4",
    name: "Bob Johnson",
    email: "headteacher@example.com",
    role: "head-teacher",
    schoolId: "1",
    schoolName: "Example School",
  },
  {
    id: "5",
    name: "Alice Brown",
    email: "teacher@example.com",
    role: "teacher",
    schoolId: "1",
    schoolName: "Example School",
    classId: "1",
    className: "Grade 5",
  },
  {
    id: "6",
    name: "David Wilson",
    email: "parent@example.com",
    role: "parent",
    schoolId: "1",
    schoolName: "Example School",
  },
  {
    id: "7",
    name: "Emma Davis",
    email: "student@example.com",
    role: "student",
    schoolId: "1",
    schoolName: "Example School",
    classId: "1",
    className: "Grade 5",
  },
  {
    id: "8",
    name: "Sarah Johnson",
    email: "nurse@example.com",
    role: "school-nurse",
    schoolId: "1",
    schoolName: "Example School",
  },
  {
    id: "9",
    name: "Michael Brown",
    email: "counselor@example.com",
    role: "school-counselor",
    schoolId: "1",
    schoolName: "Example School",
  },
]

// Authentication service
class AuthService {
  // Login method
  async login(credentials: LoginCredentials): Promise<LoginResponse> {
    // Simulate API call delay
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Find user by email and role
    const user = mockUsers.find((u) => u.email === credentials.email && u.role === credentials.role)

    // If user not found, return error
    if (!user) {
      return {
        success: false,
        message: "Invalid email or password",
      }
    }

    // If school ID is required but not provided, return error
    if (user.role !== "system-admin" && credentials.schoolId !== user.schoolId) {
      return {
        success: false,
        message: "Invalid school ID",
      }
    }

    // Return success response
    return {
      success: true,
      message: "Login successful",
      user,
    }
  }

  // Signup method
  async signup(credentials: SignupCredentials): Promise<SignupResponse> {
    // Simulate API call delay
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Check if email already exists
    const existingUser = mockUsers.find((u) => u.email === credentials.email && u.role === credentials.role)

    // If email already exists, return error
    if (existingUser) {
      return {
        success: false,
        message: "Email already exists",
      }
    }

    // Check if passwords match
    if (credentials.password !== credentials.confirmPassword) {
      return {
        success: false,
        message: "Passwords do not match",
      }
    }

    // Create new user
    const newUser: User = {
      id: uuidv4(),
      name: credentials.name,
      email: credentials.email,
      role: credentials.role,
      schoolId: credentials.schoolId,
      schoolName: credentials.schoolName,
      classId: credentials.classId,
      className: credentials.className,
    }

    // Add new user to mock users
    mockUsers.push(newUser)

    // Return success response
    return {
      success: true,
      message: "Signup successful",
      user: newUser,
    }
  }

  // Logout method
  async logout(): Promise<void> {
    // Simulate API call delay
    await new Promise((resolve) => setTimeout(resolve, 500))

    // Clear local storage
    localStorage.removeItem("userId")
    localStorage.removeItem("userRole")
    localStorage.removeItem("isAuthenticated")
  }

  // Get current user method
  getCurrentUser(): User | null {
    // Get user ID from local storage
    const userId = localStorage.getItem("userId")

    // If user ID not found, return null
    if (!userId) {
      return null
    }

    // Find user by ID
    const user = mockUsers.find((u) => u.id === userId)

    // Return user or null
    return user || null
  }

  // Check if user is authenticated
  isAuthenticated(): boolean {
    return localStorage.getItem("isAuthenticated") === "true"
  }

  // Get user role
  getUserRole(): UserRole | null {
    const role = localStorage.getItem("userRole") as UserRole | null
    return role
  }
}

// Export singleton instance
export const authService = new AuthService()
