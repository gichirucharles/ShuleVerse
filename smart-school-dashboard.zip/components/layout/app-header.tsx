"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import { AppLogo } from "@/components/layout/app-logo"
import { SchoolLogo } from "@/components/layout/school-logo"
import { UserProfileHeader } from "@/components/layout/user-profile-header"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Menu } from "lucide-react"

interface AppHeaderProps {
  schoolName?: string
  schoolLogo?: string
  userRole?: string
  userName?: string
  userAvatar?: string
}

export function AppHeader({
  schoolName = "Demo School",
  schoolLogo = "/placeholder.svg",
  userRole,
  userName,
  userAvatar,
}: AppHeaderProps) {
  const pathname = usePathname()
  const isSystemAdmin = pathname?.includes("/admin/system")
  const isHomePage = pathname === "/"

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-14 items-center justify-between">
        <div className="flex items-center gap-2 md:gap-4">
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden">
                <Menu className="h-5 w-5" />
                <span className="sr-only">Toggle menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-[300px] sm:w-[400px]">
              <nav className="flex flex-col gap-4 py-4">
                {isSystemAdmin ? (
                  <>
                    <Link href="/admin/system" className="text-lg font-medium">
                      System Dashboard
                    </Link>
                    <Link href="/admin/system/schools" className="text-lg font-medium">
                      Manage Schools
                    </Link>
                    <Link href="/admin/system/users" className="text-lg font-medium">
                      Manage Users
                    </Link>
                    <Link href="/admin/system/settings" className="text-lg font-medium">
                      System Settings
                    </Link>
                  </>
                ) : (
                  <>
                    <Link href="/dashboard" className="text-lg font-medium">
                      Dashboard
                    </Link>
                    <Link href="/students" className="text-lg font-medium">
                      Students
                    </Link>
                    <Link href="/teachers" className="text-lg font-medium">
                      Teachers
                    </Link>
                    <Link href="/classes" className="text-lg font-medium">
                      Classes
                    </Link>
                    <Link href="/reports" className="text-lg font-medium">
                      Reports
                    </Link>
                    <Link href="/settings" className="text-lg font-medium">
                      Settings
                    </Link>
                  </>
                )}
              </nav>
            </SheetContent>
          </Sheet>

          {!isHomePage && (
            <div className="flex items-center">
              {!isSystemAdmin && schoolName ? (
                <SchoolLogo logoUrl={schoolLogo} schoolName={schoolName} />
              ) : (
                <AppLogo position="left" />
              )}
            </div>
          )}
        </div>

        <div className="flex items-center gap-4">
          {!isHomePage && (
            <div className="hidden md:flex">
              <AppLogo position="right" size="small" />
            </div>
          )}

          {userName && <UserProfileHeader name={userName} role={userRole || "User"} avatarUrl={userAvatar} />}
        </div>
      </div>
    </header>
  )
}
