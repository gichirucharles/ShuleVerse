import { AppLogo } from "@/components/layout/app-logo"

export function WelcomeBanner() {
  return (
    <div className="w-full bg-gradient-to-r from-blue-50 to-blue-100 py-12 px-4 rounded-lg shadow-md">
      <div className="max-w-4xl mx-auto flex flex-col items-center text-center">
        <AppLogo position="center" size="large" showText={true} showTagline={true} />

        <h1 className="mt-8 text-3xl md:text-4xl font-bold text-[#003366]">Welcome to ShuleVerse</h1>

        <p className="mt-4 text-xl text-gray-700 max-w-2xl">
          A comprehensive school management system designed to connect schools, teachers, students, and parents in one
          unified platform.
        </p>

        <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6 w-full max-w-3xl">
          <div className="bg-white p-6 rounded-lg shadow-sm border border-blue-100">
            <h3 className="font-semibold text-lg text-[#003366]">For Schools</h3>
            <p className="mt-2 text-gray-600">Streamline administration and enhance communication</p>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-sm border border-blue-100">
            <h3 className="font-semibold text-lg text-[#003366]">For Teachers</h3>
            <p className="mt-2 text-gray-600">Simplify classroom management and student assessment</p>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-sm border border-blue-100">
            <h3 className="font-semibold text-lg text-[#003366]">For Parents</h3>
            <p className="mt-2 text-gray-600">Stay connected with your child's education journey</p>
          </div>
        </div>
      </div>
    </div>
  )
}
