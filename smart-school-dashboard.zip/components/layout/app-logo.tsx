import Image from "next/image"
import Link from "next/link"

interface AppLogoProps {
  position?: "center" | "left" | "right"
  size?: "small" | "medium" | "large"
  showText?: boolean
  showTagline?: boolean
}

export function AppLogo({ position = "left", size = "medium", showText = true, showTagline = false }: AppLogoProps) {
  // Determine size in pixels
  const sizeMap = {
    small: 32,
    medium: 48,
    large: 64,
  }

  const logoSize = sizeMap[size]
  const textSize = size === "small" ? "text-lg" : size === "medium" ? "text-xl" : "text-2xl"
  const taglineSize = size === "small" ? "text-xs" : size === "medium" ? "text-sm" : "text-base"

  // Determine position classes
  const positionClasses = {
    left: "justify-start",
    center: "justify-center",
    right: "justify-end",
  }

  return (
    <Link href="/" className={`flex items-center gap-2 ${positionClasses[position]}`}>
      <div className="relative overflow-hidden rounded-md">
        <Image
          src="/images/shuleverse-logo-new.png"
          alt="ShuleVerse Logo"
          width={logoSize}
          height={logoSize}
          className="object-contain"
        />
      </div>
      {showText && (
        <div className="flex flex-col">
          <span className={`font-bold ${textSize} text-[#003366]`}>ShuleVerse</span>
          {showTagline && <span className={`font-medium ${taglineSize} text-[#F0B323]`}>A Universe of Learning</span>}
        </div>
      )}
    </Link>
  )
}
