"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import {
  Download,
  Search,
  Filter,
  UserPlus,
  FileText,
  Phone,
  Mail,
  Award,
  TrendingUp,
  Users,
  ChevronRight,
} from "lucide-react"
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts"

export function StaffOverview() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedSchool, setSelectedSchool] = useState("all")
  const [selectedDepartment, setSelectedDepartment] = useState("all")

  // Mock staff data
  const staffOverview = {
    totalStaff: 246,
    teachers: 174,
    administrators: 42,
    support: 30,
    maleToFemaleRatio: "42:58",
    averageExperience: 8.4,
    topPerformer: "Sarah Johnson",
    topPerformanceScore: 96,
    staffSatisfaction: 87,
    teacherRetentionRate: 92,
  }

  const staffListData = [
    {
      id: "staff001",
      name: "Sarah Johnson",
      avatar: "/placeholder.svg?height=40&width=40",
      position: "Senior Teacher",
      department: "English",
      school: "Excellence Academy",
      experience: 12,
      performance: 96,
      status: "active",
      contactEmail: "sarah.johnson@edu.tz",
      contactPhone: "+255 712 345 678",
      education: "Master's in Education",
      awards: ["Teacher of the Year 2023", "Educational Excellence Award"],
    },
    {
      id: "staff002",
      name: "John Smith",
      avatar: "/placeholder.svg?height=40&width=40",
      position: "Head Teacher",
      department: "Administration",
      school: "Unity Primary School",
      experience: 15,
      performance: 94,
      status: "active",
      contactEmail: "john.smith@edu.tz",
      contactPhone: "+255 723 456 789",
      education: "PhD in Educational Leadership",
      awards: ["Educational Leadership Award", "Community Service Award"],
    },
    {
      id: "staff003",
      name: "Michael Brown",
      avatar: "/placeholder.svg?height=40&width=40",
      position: "Teacher",
      department: "Mathematics",
      school: "Pioneer Secondary School",
      experience: 8,
      performance: 88,
      status: "active",
      contactEmail: "michael.brown@edu.tz",
      contactPhone: "+255 734 567 890",
      education: "Bachelor's in Mathematics",
      awards: ["Mathematics Excellence Award"],
    },
    {
      id: "staff004",
      name: "Emily Davis",
      avatar: "/placeholder.svg?height=40&width=40",
      position: "Teacher",
      department: "Science",
      school: "Heritage International School",
      experience: 6,
      performance: 92,
      status: "active",
      contactEmail: "emily.davis@edu.tz",
      contactPhone: "+255 745 678 901",
      education: "Master's in Science Education",
      awards: ["Innovation in Teaching Award"],
    },
    {
      id: "staff005",
      name: "David Wilson",
      avatar: "/placeholder.svg?height=40&width=40",
      position: "Deputy Head",
      department: "Administration",
      school: "Lakeside International School",
      experience: 10,
      performance: 90,
      status: "active",
      contactEmail: "david.wilson@edu.tz",
      contactPhone: "+255 756 789 012",
      education: "Master's in Educational Administration",
      awards: ["Leadership Excellence Award"],
    },
    {
      id: "staff006",
      name: "Jennifer Lee",
      avatar: "/placeholder.svg?height=40&width=40",
      position: "Teacher",
      department: "Social Studies",
      school: "Greenview Primary School",
      experience: 7,
      performance: 86,
      status: "active",
      contactEmail: "jennifer.lee@edu.tz",
      contactPhone: "+255 767 890 123",
      education: "Bachelor's in History",
      awards: [],
    },
  ]

  const staffBySchoolData = [
    { name: "Excellence Academy", value: 56 },
    { name: "Unity Primary", value: 42 },
    { name: "Pioneer Secondary", value: 47 },
    { name: "Heritage Int'l", value: 38 },
    { name: "Greenview Primary", value: 34 },
    { name: "Lakeside Int'l", value: 29 },
  ]

  const staffByDepartmentData = [
    { name: "English", value: 38 },
    { name: "Mathematics", value: 35 },
    { name: "Science", value: 32 },
    { name: "Social Studies", value: 28 },
    { name: "Administration", value: 42 },
    { name: "Arts", value: 15 },
    { name: "Physical Education", value: 12 },
    { name: "ICT", value: 22 },
    { name: "Support", value: 30 },
  ]

  const performanceDistributionData = [
    { range: "90-100", value: 52, label: "Excellent" },
    { range: "80-89", value: 87, label: "Good" },
    { range: "70-79", value: 68, label: "Satisfactory" },
    { range: "60-69", value: 31, label: "Needs Improvement" },
    { range: "Below 60", value: 8, label: "Unsatisfactory" },
  ]

  // Colors for pie charts
  const STAFF_COLORS = ["#4f46e5", "#22c55e", "#eab308", "#f97316", "#ef4444", "#8b5cf6"]
  const PERFORMANCE_COLORS = ["#22c55e", "#3b82f6", "#eab308", "#f97316", "#ef4444"]

  // Filter staff based on search query, school, and department
  const filteredStaff = staffListData.filter((staff) => {
    const matchesSearch =
      staff.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      staff.position.toLowerCase().includes(searchQuery.toLowerCase()) ||
      staff.department.toLowerCase().includes(searchQuery.toLowerCase())

    const matchesSchool = selectedSchool === "all" || staff.school === selectedSchool
    const matchesDepartment = selectedDepartment === "all" || staff.department === selectedDepartment

    return matchesSearch && matchesSchool && matchesDepartment
  })

  return (
    <Card>
      <CardHeader>
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <CardTitle>Staff Overview</CardTitle>
            <CardDescription>Manage and monitor staff across all schools</CardDescription>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <Button>
              <UserPlus className="mr-2 h-4 w-4" />
              Add Staff
            </Button>
            <Button variant="outline">
              <Download className="mr-2 h-4 w-4" />
              Export
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="overview">
          <TabsList className="grid w-full grid-cols-3 mb-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="staff-list">Staff List</TabsTrigger>
            <TabsTrigger value="performance">Performance</TabsTrigger>
          </TabsList>
          
          <TabsContent value="overview" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Total Staff</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center">
                    <div className="mr-4 rounded-full bg-blue-100 p-2">
                      <Users className="h-4 w-4 text-blue-600" />
                    </div>
                    <div>
                      <div className="flex items-end">
                        <span className="text-2xl font-bold mr-2">{staffOverview.totalStaff}</span>
                        <span className="text-sm text-gray-500 mb-1">staff members</span>
                      </div>
                      <div className="flex flex-wrap text-xs text-gray-600 gap-x-3">
                        <span>{staffOverview.teachers} Teachers</span>
                        <span>{staffOverview.administrators} Administrators</span>
                        <span>{staffOverview.support} Support</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Teacher Retention</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="text-2xl font-bold">{staffOverview.teacherRetentionRate}%</div>
                    <Progress value={staffOverview.teacherRetentionRate} className="h-2" />
                    <p className="text-xs text-gray-500">Annual teacher retention rate</p>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Top Performer</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center">
                    <div className="mr-4 rounded-full bg-amber-100 p-2">
                      <Award className="h-4 w-4 text-amber-600" />
                    </div>
                    <div>
                      <div className="text-lg font-bold">{staffOverview.topPerformer}</div>
                      <div className="flex items-center text-xs text-amber-600">
                        Performance Score: {staffOverview.topPerformanceScore}/100
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Staff Distribution by School</CardTitle>
                  <CardDescription>Number of staff members across schools</CardDescription>
                </CardHeader>
                <CardContent className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={staffBySchoolData}
                        cx="50%"
                        cy="50%"
                        labelLine={true}
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {staffBySchoolData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={STAFF_COLORS[index % STAFF_COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Staff Distribution by Department</CardTitle>
                  <CardDescription>Number of staff members by department</CardDescription>
                </CardHeader>
                <CardContent className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={staffByDepartmentData} layout="vertical">
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis type="number" />
                      <YAxis dataKey="name" type="category" width={100} />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="value" name="Staff Members" fill="#4f46e5" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Performance Distribution</CardTitle>
                  <CardDescription>Staff performance score ranges</CardDescription>
                </CardHeader>
                <CardContent className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={performanceDistributionData}
                        cx="50%"
                        cy="50%"
                        labelLine={true}
                        label={({ name, value, percent }) => 
                          `${performanceDistributionData[name]?.range}: ${(percent * 100).toFixed(0)}%`
                        }
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        nameKey="range"
                      >
                        {performanceDistributionData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={PERFORMANCE_COLORS[index % PERFORMANCE_COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Staff Satisfaction & Demographics</CardTitle>
                  <CardDescription>Staff satisfaction and demographic data</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm font-medium">Staff Satisfaction</span>
                        <span className="font-bold">{staffOverview.staffSatisfaction}%</span>
                      </div>
                      <Progress value={staffOverview.staffSatisfaction} className="h-2" />
                      <p className="text-xs text-gray-500">Based on latest staff survey</p>
                    </div>
                    
                    <div className="space-y-4">
                      <h4 className="text-sm font-semibold">Demographics</h4>
                      
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Gender Ratio (M:F)</span>
                        <Badge variant="outline">{staffOverview.maleToFemaleRatio}</Badge>
                      </div>
                      
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Average Experience</span>
                        <Badge variant="outline">{staffOverview.averageExperience} years</Badge>
                      </div>
                      
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Advanced Degrees</span>
                        <Badge variant="outline">42%</Badge>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          <TabsContent value="staff-list">
            <div className="flex flex-col md:flex-row items-center gap-4 mb-4">
              <div className="relative flex-1">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search staff..."
                  className="pl-8"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              
              <Select value={selectedSchool} onValueChange={setSelectedSchool}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Select school" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Schools</SelectItem>
                  <SelectItem value="Excellence Academy">Excellence Academy</SelectItem>
                  <SelectItem value="Unity Primary School">Unity Primary</SelectItem>
                  <SelectItem value="Pioneer Secondary School">Pioneer Secondary</SelectItem>
                  <SelectItem value="Heritage International School">Heritage Int'l</SelectItem>
                  <SelectItem value="Greenview Primary School">Greenview Primary</SelectItem>
                  <SelectItem value="Lakeside International School">Lakeside Int'l</SelectItem>
                </SelectContent>
              </Select>
              
              <Select value={selectedDepartment} onValueChange={setSelectedDepartment}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Select department" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Departments</SelectItem>
                  <SelectItem value="Administration">Administration</SelectItem>
                  <SelectItem value="English">English</SelectItem>
                  <SelectItem value="Mathematics">Mathematics</SelectItem>
                  <SelectItem value="Science">Science</SelectItem>
                  <SelectItem value="Social Studies">Social Studies</SelectItem>
                  <SelectItem value="Arts">Arts</SelectItem>
                  <SelectItem value="ICT">ICT</SelectItem>
                </SelectContent>
              </Select>
              
              <Button variant="outline" size="icon">
                <Filter className="h-4 w-4" />
              </Button>
            </div>
            
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Position</TableHead>
                    <TableHead>School</TableHead>
                    <TableHead>Department</TableHead>
                    <TableHead>Experience</TableHead>
                    <TableHead>Performance</TableHead>
                    <TableHead>Contact</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredStaff.map((staff) => (
                    <TableRow key={staff.id}>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <Avatar className="h-9 w-9">
                            <AvatarImage src={staff.avatar || "/placeholder.svg"} alt={staff.name} />
                            <AvatarFallback>{staff.name.substring(0, 2).toUpperCase()}</AvatarFallback>
                          </Avatar>
                          <div>
                            <div className="font-medium">{staff.name}</div>
                            <div className="text-xs text-gray-500">{staff.education}</div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>{staff.position}</TableCell>
                      <TableCell>{staff.school}</TableCell>
                      <TableCell>{staff.department}</TableCell>
                      <TableCell>{staff.experience} years</TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-2">
                          <Progress value={staff.performance} className="h-2 w-16" />
                          <span className="text-sm">{staff.performance}%</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-col text-xs">
                          <div className="flex items-center">
                            <Mail className="h-3 w-3 mr-1 text-gray-500" />
                            <span>{staff.contactEmail}</span>
                          </div>
                          <div className="flex items-center">
                            <Phone className="h-3 w-3 mr-1 text-gray-500" />
                            <span>{staff.contactPhone}</span>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm">
                          <FileText className="h-4 w-4 mr-2" />
                          View Profile
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </TabsContent>
          
          <TabsContent value="performance">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Staff Performance Analysis</CardTitle>
                <CardDescription>Performance metrics across all staff members</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="rounded-md border mb-6">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Performance Level</TableHead>
                        <TableHead>Score Range</TableHead>
                        <TableHead>Number of Staff</TableHead>
                        <TableHead>Percentage</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {performanceDistributionData.map((item) => (
                        <TableRow key={item.range}>
                          <TableCell className="font-medium">{item.label}</TableCell>
                          <TableCell>{item.range}</TableCell>
                          <TableCell>{item.value}</TableCell>
                          <TableCell>
                            {((item.value / staffOverview.totalStaff) * 100).toFixed(1)}%
                          </TableCell>
                          <TableCell className="text-right">
                            <Button variant="ghost" size="sm">
                              <ChevronRight className="h-4 w-4 mr-2" />
                              View Staff
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
                
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={performanceDistributionData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="range" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="value" name="Number of Staff" fill="#4f46e5" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
                
                <div className="mt-6 bg-blue-50 border border-blue-200 rounded-md p-4">
                  <h3 className="text-lg font-semibold text-blue-800 mb-2">Performance Insights</h3>
                  <ul className="space-y-2">
                    <li className="flex items-start text-sm text-blue-700">
                      <TrendingUp className="h-4 w-4 mr-2 mt-0.5 text-blue-600" />
                      <span>
                        {performanceDistributionData[0].value} staff members ({((performanceDistributionData[0].value / staffOverview.totalStaff) * 100).toFixed(1)}%) are performing at excellent levels.
                      </span>
                    </li>
                    <li className="flex items-start text-sm text-blue-700">
                      <Award className="h-4 w-4 mr-2 mt-0.5 text-blue-600" />
                      <span>
                        The top-performing department is English with an average score of 88%.
                      </span>
                    </li>
                    <li className="flex items-start text-sm text-blue-700">
                      <Award className="h-4 w-4 mr-2 mt-0.5 text-blue-600" />
                      <span>\
                        {performanceDistributionData[3].value + performanceDistributionData[4].value} staff members ({((performanceDistributionData[3].value + performanceDistributionData[4].value) / staffOverview.totalStaff) * 100).toFixed(1)}\%) require additional support to improve performance.
                      </span>
                    </li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}
