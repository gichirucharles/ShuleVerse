"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { type AdminRole, getRoleConfig } from "@/lib/roles-config"
import { authService, type LoginCredentials } from "@/lib/auth-service"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import Link from "next/link"

interface RoleLoginProps {
  role: AdminRole
}

export function RoleLogin({ role }: RoleLoginProps) {
  const router = useRouter()
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)

  const roleConfig = getRoleConfig(role)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError("")

    try {
      const credentials: LoginCredentials = {
        email,
        password,
        role,
      }

      const response = await authService.login(credentials)

      if (response.success) {
        if (response.isFirstLogin) {
          // Redirect to change password page
          router.push("/change-password")
        } else {
          // Redirect to role-specific dashboard
          router.push(roleConfig.dashboardPath)
        }
      } else {
        setError(response.message)
      }
    } catch (err) {
      setError("An unexpected error occurred. Please try again.")
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle>{roleConfig.name} Login</CardTitle>
        <CardDescription>
          Enter your credentials to access the {roleConfig.name.toLowerCase()} dashboard
        </CardDescription>
      </CardHeader>
      <CardContent>
        {error && (
          <Alert variant="destructive" className="mb-4">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              placeholder="your.email@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label htmlFor="password">Password</Label>
              <Link href="/forgot-password" className="text-sm text-blue-600 hover:underline">
                Forgot password?
              </Link>
            </div>
            <Input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          <Button type="submit" className="w-full" disabled={loading}>
            {loading ? "Logging in..." : "Login"}
          </Button>
        </form>
      </CardContent>
      <CardFooter className="flex flex-col space-y-2">
        <div className="text-sm text-center">
          Don't have an account?{" "}
          <Link href={`/signup/${role}`} className="text-blue-600 hover:underline">
            Sign up
          </Link>
        </div>
        <div className="text-sm text-center">
          <Link href="/admin-select" className="text-blue-600 hover:underline">
            Login as a different role
          </Link>
        </div>
      </CardFooter>
    </Card>
  )
}
